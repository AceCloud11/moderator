module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {},
    // colors: {
    //   primary: "#30365aa4",
    //   background: "#0c0f21",
    // },
  },
  plugins: [],
};
